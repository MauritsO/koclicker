KO Clicker
=========

The most awesome idle-game out there


TODO:  
-Battle  
-<strike>healthbar animation</strike>    
-icons in shop   
-add challenges/rewards  
-improve shop dropdown menu  
-start cashflow(sponsorship) at certain strength  
-optimize cash flow  
-more items in shop  
-<strike>find cheap/free hosting</strike>    
-<strike>link to koclicker.com</strike>  
-add enemies  
-<strike>add paypal donate button</strike>  
-optimize enemy stats  
-post to reddit/facebook/telekids.nl  
-????  
-PROFIT!!  

